import os
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from sklearn.metrics import confusion_matrix, classification_report
import seaborn as sns

# Paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data", "spectrograms")
MODEL_PATH = os.path.join(BASE_DIR, "outputs", "models", "instrunet_cnn_model.h5")

IMG_SIZE = (128, 128)
BATCH_SIZE = 32

# Load model
model = tf.keras.models.load_model(MODEL_PATH)

# Data generator (validation only)
datagen = tf.keras.preprocessing.image.ImageDataGenerator(rescale=1./255)

val_data = datagen.flow_from_directory(
    DATA_DIR,
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode="categorical",
    shuffle=False
)

# Predictions
y_pred = model.predict(val_data)
y_pred_classes = np.argmax(y_pred, axis=1)
y_true = val_data.classes
class_names = list(val_data.class_indices.keys())

# 1. Confusion Matrix
cm = confusion_matrix(y_true, y_pred_classes)

plt.figure(figsize=(10, 8))
sns.heatmap(
    cm,
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=class_names,
    yticklabels=class_names
)

plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")

# 🔽 SAVE HERE
CONF_MATRIX_PATH = os.path.join(BASE_DIR, "outputs", "confusion_matrix.png")
plt.savefig(CONF_MATRIX_PATH, dpi=300, bbox_inches="tight")

plt.show()
print("Confusion matrix saved at:", CONF_MATRIX_PATH)

# 2. Class-wise performance
print("Class-wise Performance:\n")
print(classification_report(y_true, y_pred_classes, target_names=class_names))

# 3. Identify misclassified samples
misclassified = np.where(y_pred_classes != y_true)[0]
print(f"Total misclassified samples: {len(misclassified)}")

# Show first 5 misclassified image names
for i in misclassified[:5]:
    print(val_data.filenames[i])
