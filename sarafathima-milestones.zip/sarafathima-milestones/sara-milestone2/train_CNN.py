import os
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import pickle


BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data", "spectrograms")
MODEL_DIR = os.path.join(BASE_DIR, "outputs", "models")
os.makedirs(MODEL_DIR, exist_ok=True)
IMG_SIZE = (128, 128)
BATCH_SIZE = 32
EPOCHS = 35


train_datagen = ImageDataGenerator(
    rescale=1./255,
    validation_split=0.1,
    rotation_range=15,
    width_shift_range=0.1,
    height_shift_range=0.1,
    zoom_range=0.1,
    horizontal_flip=True
)

val_datagen = ImageDataGenerator(
    rescale=1./255,
    validation_split=0.1
)


train_data = train_datagen.flow_from_directory(
    DATA_DIR,
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode="categorical",
    subset="training"
)

val_data = val_datagen.flow_from_directory(
    DATA_DIR,
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode="categorical",
    subset="validation"
)


print("Class indices:", train_data.class_indices)


images, labels = next(train_data)
print("Batch image shape:", images.shape, "Batch labels shape:", labels.shape)


model = Sequential([
    Conv2D(32, (3,3), activation="relu", input_shape=(128,128,3)),
    MaxPooling2D(2,2),

    Conv2D(64, (3,3), activation="relu"),
    MaxPooling2D(2,2),

    Conv2D(128, (3,3), activation="relu"),
    MaxPooling2D(2,2),

    Conv2D(256, (3,3), activation="relu"),  
    MaxPooling2D(2,2),

    Flatten(),
    Dense(256, activation="relu"),          
    Dropout(0.2),
    Dense(train_data.num_classes, activation="softmax")
])


model.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=0.0005),  # smaller LR
    loss="categorical_crossentropy",
    metrics=["accuracy"]
)


history = model.fit(
    train_data,
    validation_data=val_data,
    epochs=EPOCHS
)
HISTORY_PATH = os.path.join(BASE_DIR, "outputs","history_lr_0.0005_dropout_0.2.pkl")
with open(HISTORY_PATH, "wb") as f:
    pickle.dump(history.history, f)

print("Training history with adjusted learning rate_0.0005 and dropout_0.2 saved at:", HISTORY_PATH)

MODEL_PATH = os.path.join(MODEL_DIR, "instrunet_cnn_model.h5")
model.save(MODEL_PATH)
print("Model saved at:", MODEL_PATH)
