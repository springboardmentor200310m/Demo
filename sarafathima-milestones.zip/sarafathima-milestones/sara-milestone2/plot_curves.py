import pickle
import os
import matplotlib.pyplot as plt

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HISTORY_PATH = os.path.join(BASE_DIR, "outputs", "history_lr_0.0005_dropout_0.2.pkl")
PLOT_DIR = os.path.join(BASE_DIR, "outputs", "plots")

os.makedirs(PLOT_DIR, exist_ok=True)

# Load history
with open(HISTORY_PATH, "rb") as f:
    history = pickle.load(f)

# ---------- Accuracy Curve ----------
plt.figure()
plt.plot(history["accuracy"], label="Training Accuracy")
plt.plot(history["val_accuracy"], label="Validation Accuracy")
plt.xlabel("Epochs")
plt.ylabel("Accuracy")
plt.legend()
plt.title("Accuracy Curve")

acc_path = os.path.join(PLOT_DIR, "accuracy_curve.png")
plt.savefig(acc_path)
plt.close()

# ---------- Loss Curve ----------
plt.figure()
plt.plot(history["loss"], label="Training Loss")
plt.plot(history["val_loss"], label="Validation Loss")
plt.xlabel("Epochs")
plt.ylabel("Loss")
plt.legend()
plt.title("Loss Curve")

loss_path = os.path.join(PLOT_DIR, "loss_curve.png")
plt.savefig(loss_path)
plt.close()

print("Plots saved at:")
print(acc_path)
print(loss_path)
